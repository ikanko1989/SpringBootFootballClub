package com.example.FootballClub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FootballClubApplication {

	public static void main(String[] args) {
		SpringApplication.run(FootballClubApplication.class, args);
	}

}
