package com.example.FootballClub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FootballClubApplicationTests {

	@Test
	void contextLoads() {
	}

}
